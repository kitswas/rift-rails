// packages/field-repair/main.ts
var plugin = {
  mount(api) {
    const CRITICAL_HULL = 30;
    const REPAIR_AMOUNT = 25;
    const STORAGE_KEY = "stabilizer";
    const readUsed = (saved) => !!saved && typeof saved === "object" && saved.used === true;
    const errText = (err) => err instanceof Error ? err.message : String(err);
    let expended = false;
    let inFlight = false;
    const seeded = api.storage.get(STORAGE_KEY).then((saved) => {
      if (readUsed(saved)) expended = true;
    }).catch((err) => {
      api.log(`field-repair: stabilizer seed error (${errText(err)})`);
    });
    function isTerminal(phase) {
      return phase === "DEAD" || phase === "STRANDED";
    }
    function isCritical(hull) {
      return Number.isFinite(hull) && hull <= CRITICAL_HULL;
    }
    async function maybeDeploy() {
      if (expended || inFlight) return;
      const before = api.state();
      if (!before || isTerminal(before.phase) || !isCritical(before.hull)) return;
      inFlight = true;
      try {
        if (readUsed(await api.storage.get(STORAGE_KEY))) {
          expended = true;
          return;
        }
        const during = api.state();
        if (!during || isTerminal(during.phase) || !isCritical(during.hull)) return;
        const result = await api.grant({
          kind: "adjustResource",
          resource: "hull",
          amount: REPAIR_AMOUNT
        });
        if (!result || result.ok !== true) {
          api.log(
            `field-repair: stabilizer failed to deploy (${result && result.reason || "unknown"}); it stays armed while hull is critical`
          );
          return;
        }
        expended = true;
        await api.storage.set(STORAGE_KEY, {
          used: true,
          jump: during.jumpCount,
          hullBefore: during.hull
        });
        api.log(
          `field-repair: emergency hull stabilizer deployed at jump ${during.jumpCount} (hull ${during.hull}, +${REPAIR_AMOUNT} hull)`
        );
      } catch (err) {
        api.log(`field-repair: stabilizer error (${errText(err)})`);
      } finally {
        inFlight = false;
      }
    }
    api.on("afterAction", () => {
      void maybeDeploy();
    });
    api.on("afterJump", async () => {
      await seeded;
      await maybeDeploy();
      if (expended) {
        const s = api.state();
        api.log(`field-repair: stabilizer spent (jump ${s ? s.jumpCount : "?"})`);
      } else {
        api.log("field-repair: stabilizer ready");
      }
    });
  },
  unmount() {
  }
};
var main_default = plugin;
export {
  main_default as default
};
