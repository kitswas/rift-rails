// packages/rift-salvager/main.ts
var MELT_ACTION_ID = "rift-salvager:salvage_melt";
var plugin = {
  mount(api) {
    api.registerAction({
      id: "salvage_melt",
      label: "Salvage Melt",
      desc: "Smelt 10 Fuel and 1 Energy into 20 Flux. Lossy, but works away from hub contracts.",
      consumes: [
        { res: "energy", amount: 1 },
        { res: "fuel", amount: 10 }
      ],
      produces: [{ res: "flux", amount: 20 }],
      logSuccess: "Salvage furnace melted fuel canisters into 20 Flux."
    });
    api.registerNode({
      id: "salvage_yard",
      label: "Salvage Yard",
      desc: "A drifting yard where wreck cores are smelted for flux.",
      exploreCost: 1,
      isHub: false,
      actions: ["salvage_melt"]
    });
    let meltsThisJump = null;
    async function seedMelts() {
      if (meltsThisJump !== null) return meltsThisJump;
      const prev = await api.storage.get("meltsThisJump");
      meltsThisJump = typeof prev === "number" && Number.isFinite(prev) ? prev : 0;
      return meltsThisJump;
    }
    const errText = (err) => err instanceof Error ? err.message : String(err);
    api.on("afterAction", async (payload) => {
      try {
        const p = payload;
        const actionId = p && typeof p.actionId === "string" ? p.actionId : "";
        if (actionId !== MELT_ACTION_ID) return;
        if (!p || p.success !== true) return;
        const current = await seedMelts();
        meltsThisJump = current + 1;
        await api.storage.set("meltsThisJump", meltsThisJump);
        api.log(`rift-salvager: melt ${meltsThisJump} this jump`);
      } catch (err) {
        api.log(`rift-salvager: afterAction error (${errText(err)})`);
      }
    });
    api.on("afterJump", async (payload) => {
      try {
        const p = payload;
        const jumpCount = p && typeof p.jumpCount === "number" && Number.isFinite(p.jumpCount) ? p.jumpCount : 0;
        meltsThisJump = 0;
        await api.storage.set("meltsThisJump", 0);
        await api.storage.set("lastJump", jumpCount);
      } catch (err) {
        api.log(`rift-salvager: afterJump error (${errText(err)})`);
      }
    });
  },
  unmount() {
  }
};
var main_default = plugin;
export {
  main_default as default
};
